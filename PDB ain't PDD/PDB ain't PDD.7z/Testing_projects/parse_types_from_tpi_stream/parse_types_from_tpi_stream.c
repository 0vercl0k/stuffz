#include <windows.h>
#include <stdio.h>

#define LF_ARRAY     0x00001503
#define LF_BITFIELD  0x00001205
#define LF_CLASS     0x00001504
#define LF_STRUCTURE 0x00001505
#define LF_UNION     0x00001506
#define LF_ENUM      0x00001507
#define LF_POINTER   0x00001002
#define LF_PROCEDURE 0x00001008
#define LF_MFUNCTION 0x00001009
#define LF_ARGLIST   0x00001201
#define LF_VTSHAPE   0x0000000A
#define LF_FIELDLIST 0x00001203

#pragma pack(1)
typedef struct
{
    /*000.0*/ WORD access      : 2; // CV_access_e
    /*000.2*/ WORD mprop       : 3; // CV_methodprop_e
    /*000.5*/ WORD pseudo      : 1;
    /*000.6*/ WORD noinherit   : 1;
    /*000.7*/ WORD noconstruct : 1;
    /*001.0*/ WORD compgenx    : 1;
    /*001.1*/ WORD unused      : 7;
} CV_fldattr_t, *PCV_fldattr_t, **PPCV_fldattr_t;

typedef struct
{
    /*000.0*/ WORD packed   : 1;
    /*000.1*/ WORD ctor     : 1;
    /*000.2*/ WORD ovlops   : 1;
    /*000.3*/ WORD isnested : 1;
    /*000.4*/ WORD cnested  : 1;
    /*000.5*/ WORD opassign : 1;
    /*000.6*/ WORD opcast   : 1;
    /*000.7*/ WORD fwdref   : 1;
    /*001.0*/ WORD scoped   : 1;
    /*001.1*/ WORD reserved : 7;
} CV_prop_t, *PCV_prop_t, **PPCV_prop_t;

typedef struct         // array
{
    /*000*/ WORD  leaf;             // LF_ARRAY
    /*002*/ DWORD elemtype;         // element type index
    /*006*/ DWORD idxtype;          // indexing type index
    /*00A*/ BYTE  data [];          // size in bytes
} lfArray, *PlfArray, **PPlfArray;

typedef struct      // bitfield structure
{
    /*000*/ WORD  leaf;             // LF_BITFIELD
    /*002*/ DWORD type;             // base type index
    /*006*/ BYTE  length;           // number of bits
    /*007*/ BYTE  position;         // bit offset of bit 0
} lfBitfield, *PlfBitfield, **PPlfBitfield;

typedef struct         // class or structure
{
    /*000*/ WORD      leaf;         // LF_CLASS, LF_STRUCTURE
    /*002*/ WORD      count;        // number of members
    /*004*/ CV_prop_t property;     // type properties
    /*006*/ DWORD     field;        // LF_FIELD descriptor index
    /*00A*/ DWORD     derived;
    /*00E*/ DWORD     vshape;
    /*012*/ BYTE      data [];      // size and name
} lfClass, *PlfClass, **PPlfClass;

typedef lfClass lfStructure, *PlfStructure, **PPlfStructure;

typedef struct         // union
{
/*000*/ WORD      leaf;         // LF_UNION
/*002*/ WORD      count;        // number of members
/*004*/ CV_prop_t property;     // type properties
/*006*/ DWORD     field;        // LF_FIELD descriptor index
/*00A*/ BYTE      data [];      // size and name
} lfUnion, *PlfUnion, **PPlfUnion;

typedef struct          // enumeration
{
    /*000*/ WORD      leaf;         // LF_ENUM
    /*002*/ WORD      count;        // number of members
    /*004*/ CV_prop_t property;     // type properties
    /*006*/ DWORD     utype;        // underlying type
    /*00A*/ DWORD     field;        // LF_FIELD descriptor index
    /*00E*/ BYTE      Name [];      // name
} lfEnum, *PlfEnum, **PPlfEnum;

typedef struct       // pointer to type
{
    /*000*/ struct lfPointerBody
    /*000*/ {
    /*000*/      WORD  leaf;         // LF_POINTER
    /*002*/      DWORD utype;        // underlying type
    /*006*/      struct lfPointerAttr
    /*006*/      {
    /*006.0*/        DWORD ptrtype     :  5; // pointer type
    /*006.5*/        DWORD ptrmode     :  3; // pointer mode
    /*007.0*/        DWORD isflat32    :  1; // 0:32 pointer
    /*007.1*/        DWORD isvolatile  :  1; // volatile pointer
    /*007.2*/        DWORD isconst     :  1; // constant pointer
    /*007.3*/        DWORD isunaligned :  1; // unaligned pointer
    /*007.4*/        DWORD isrestrict  :  1; // restricted pointer
    /*007.5*/        DWORD unused      : 19; // currently unused
    /*00A*/       } attr;
    /*00A*/  };
    /*00A*/  union
    /*00A*/  {
    /*00A*/       struct
    /*00A*/       {
    /*00A*/           DWORD pmclass;
    /*00E*/           WORD  pmenum;
    /*010*/       } pm;
    /*00A*/       WORD bseg;
    /*00A*/       BYTE Sym [];
    /*00A*/       struct
    /*00A*/       {
    /*00A*/           DWORD index;
    /*00E*/           BYTE  name [];
    /*00E*/       } btype;
    /*010*/   } pbase;
} lfPointer, *PlfPointer, **PPlfPointer;

typedef struct          // procedure
{
    /*000*/ WORD  leaf;             // LF_PROCEDURE
    /*002*/ DWORD rvtype;           // return value type
    /*006*/ BYTE  calltype;         // calling convention (CV_call_e)
    /*007*/ BYTE  reserved;         // currently not used
    /*008*/ WORD  parmcount;        // number of parameters
    /*00A*/ DWORD arglist;          // argument list type
} lfProc, *PlfProc, **PPlfProc;

typedef struct         // member function
{
    /*000*/ WORD  leaf;             // LF_MFUNCTION
    /*002*/ DWORD rvtype;           // return value type
    /*006*/ DWORD classtype;        // containing class type
    /*00A*/ DWORD thistype;         // this-pointer type
    /*00E*/ BYTE  calltype;         // calling convention (CV_call_e)
    /*00F*/ BYTE  reserved;         // currently not used
    /*010*/ WORD  parmcount;        // number of parameters
    /*012*/ DWORD arglist;          // argument list type
    /*016*/ LONG  thisadjust;       // this-adjuster
} lfMFunc, *PlfMFunc, **PPlfMFunc;

typedef struct       // procedure argument list
{
/*000*/ WORD  leaf;             // LF_ARGLIST
/*002*/ DWORD count;            // number of arguments
/*006*/ DWORD arg [];           // argument types
} lfArgList, *PlfArgList, **PPlfArgList;

typedef struct       // virtual function table shape
{
    /*000*/ WORD leaf;              // LF_VTSHAPE
    /*002*/ WORD count;             // number of VFT entries
    /*004*/ BYTE desc [];           // 4-bit descriptor list
} lfVTShape, *PlfVTShape, **PPlfVTShape;

typedef struct     // enumeration member
{
    /*000*/ WORD         leaf;      // LF_ENUMERATE
    /*002*/ CV_fldattr_t attr;
    /*004*/ BYTE         value [];
} lfEnumerate, *PlfEnumerate, **PPlfEnumerate;

typedef struct        // non-static data member
{
    /*000*/ WORD         leaf;      // LF_MEMBER
    /*002*/ CV_fldattr_t attr;
    /*004*/ DWORD        index;
    /*008*/ BYTE         offset [];
} lfMember, *PlfMember, **PPlfMember;

typedef struct        // base class field
{
    /*000*/ WORD         leaf;      // LF_BCLASS
    /*002*/ CV_fldattr_t attr;
    /*004*/ DWORD        index;
    /*008*/ BYTE         offset [];
} lfBClass, *PlfBClass, **PPlfBClass;

typedef struct      // virtual function table pointer
{
    /*000*/ WORD  leaf;             // LF_VFUNCTAB
    /*002*/ WORD  pad0;             // padding
    /*004*/ DWORD type;             // VFT pointer type
} lfVFuncTab, *PlfVFuncTab, **PPlfVFuncTab;

typedef struct    // non-overloaded method
{
    /*000*/ WORD         leaf;      // LF_ONEMETHOD
    /*002*/ CV_fldattr_t attr;
    /*004*/ DWORD        index;
    /*008*/ DWORD        vbaseoff []; // VFT base offset, if present
} lfOneMethod, *PlfOneMethod, **PPlfOneMethod;

typedef struct       // overloaded method list
{
    /*000*/ WORD  leaf;             // LF_METHOD
    /*002*/ WORD  count;            // number of occurrences
    /*004*/ DWORD mList;            // LF_METHODLIST descriptor index
    /*008*/ BYTE  Name [];
} lfMethod, *PlfMethod, **PPlfMethod;

typedef struct     // nested type definition
{
    /*000*/ WORD  leaf;             // LF_NESTTYPE
    /*002*/ WORD  pad0;
    /*004*/ DWORD index;
    /*008*/ BYTE  Name [];
} lfNestType, *PlfNestType, **PPlfNestType;

typedef union
{
    /*000*/ WORD        leaf;      // LF_*
    /*000*/ lfEnumerate Enumerate; // LF_ENUMERATE
    /*000*/ lfMember    Member;    // LF_MEMBER
    /*000*/ lfBClass    BClass;    // LF_BCLASS
    /*000*/ lfVFuncTab  VFuncTab;  // LF_VFUNCTAB
    /*000*/ lfOneMethod OneMethod; // LF_ONEMETHOD
    /*000*/ lfMethod    Method;    // LF_METHOD
    /*000*/ lfNestType  NestType;  // LF_NESTTYPE
} lfSubRecord, *PlfSubRecord, **PPlfSubRecord;

typedef struct     // struct/union/enum members
{
    /*000*/ WORD        leaf;       // LF_FIELDLIST
    /*002*/ lfSubRecord SubRecord;
} lfFieldList, *PlfFieldList, **PPlfFieldList;

typedef union
{
    /*000*/ WORD        leaf;      // LF_*
    /*000*/ lfArray     Array;     // LF_ARRAY
    /*000*/ lfBitfield  Bitfield;  // LF_BITFIELD
    /*000*/ lfClass     Class;     // LF_CLASS
    /*000*/ lfStructure Structure; // LF_STRUCTURE
    /*000*/ lfUnion     Union;     // LF_UNION
    /*000*/ lfEnum      Enum;      // LF_ENUM
    /*000*/ lfPointer   Pointer;   // LF_POINTER
    /*000*/ lfProc      Proc;      // LF_PROCEDURE
    /*000*/ lfMFunc     MFunc;     // LF_MFUNCTION
    /*000*/ lfArgList   ArgList;   // LF_ARGLIST
    /*000*/ lfVTShape   VTShape;   // LF_VTSHAPE
    /*000*/ lfFieldList FieldList; // LF_FIELDLIST
} lfRecord, *PlfRecord, **PPlfRecord;

typedef struct
{
    signed int offset;
    signed int count;
} OFFSET_COUNT;

typedef struct
{
    unsigned short sn;
    unsigned char padding[2];
    signed int hash_key;
    signed int buckets;
    OFFSET_COUNT hash_values;
    OFFSET_COUNT ti_off;
    OFFSET_COUNT hash_adj;
} TPI_HASH, *PTPI_HASH;

typedef struct
{
    unsigned int version;
    signed int header_size;    // header size in bytes
    unsigned int ti_min;       // type index base
    unsigned int ti_max;       // type index limit
    unsigned int follow_size;  // size of follow-up data
    TPI_HASH tpi_hash;
} HEADER, *PHEADER;
#pragma pack()


char *type_to_str(unsigned int type)
{
    switch(type)
    {
        case LF_ARRAY:
            return "LF_ARRAY";
        case LF_BITFIELD:
            return "LF_BITFIELD";
        case LF_CLASS:
            return "LF_CLASS";
        case LF_STRUCTURE:
            return "LF_STRUCTURE";
        case LF_UNION:
            return "LF_UNION";
        case LF_ENUM:
            return "LF_ENUM";
        case LF_POINTER:
            return "LF_POINTER";
        case LF_PROCEDURE:
            return "LF_PROCEDURE";
        case LF_MFUNCTION:
            return "LF_MFUNCTION";
        case LF_ARGLIST:
            return "LF_ARGLIST";
        case LF_VTSHAPE:
            return "LF_VTSHAPE";
        case LF_FIELDLIST:
            return "LF_FIELDLIST";

        default:
            return "UNKNOWN";
    }
}

void display_header(PHEADER hdr)
{
    printf("Header\n");
    printf("version: %.8x\n", hdr->version);
    printf("header size: %d\n", hdr->header_size);
    printf("type index base: %d\n", hdr->ti_min);
    printf("type index max: %d\n", hdr->ti_max);
    printf("number of types: %d\n", hdr->ti_max - hdr->ti_min);
    printf("follow size: %d\n", hdr->follow_size);
}


PVOID map_stream_types(char* name)
{
    PVOID base_file = NULL;
    HANDLE hFile, hFileMap;

    hFile = CreateFile(
        name,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if(hFile == INVALID_HANDLE_VALUE)
    {
        printf("CreateFile failed.\n");
        return NULL;
    }

    hFileMap = CreateFileMapping(
        hFile,
        NULL,
        PAGE_READONLY,
        0,
        0,
        NULL
    );

    if(hFileMap == INVALID_HANDLE_VALUE)
    {
        printf("CreateFileMapping.\n");
        return NULL;
    }

    base_file = MapViewOfFile(
        hFileMap,
        FILE_MAP_READ,
        0,
        0,
        0
    );

    if(base_file == NULL)
    {
        printf("MapViewOfFile.\n");
        return NULL;
    }

    return base_file;
}

int main(int argc, char* argv[])
{
    unsigned int i = 0, offset = 0;
    PHEADER hdr = NULL;
    PVOID base = map_stream_types("trigger.pdb.002");
    PUCHAR ptr = base;
    unsigned short length = 0;
    PlfRecord record = {0};

    printf("File mapped at: %.8x\n", base);

    //1] Header
    hdr = (PHEADER)base;
    display_header(hdr);

    ptr += sizeof(HEADER);
    offset += sizeof(HEADER);

    //2] Pick a type
    for(; i < (hdr->ti_max - hdr->ti_min); ++i)
    {
        length = *(unsigned short*)ptr;
        ptr += sizeof(unsigned short);

        record = (PlfRecord)ptr;
        printf("ID: %.4x, Type: %.8x, Size: %.4x, Offset: %.8x -- %s ", hdr->ti_min + i, record->leaf, length, offset, type_to_str(record->leaf));
        switch(record->leaf)
        {
            case LF_PROCEDURE:
            {
                    printf("RetType: %.8x ; calltype: %.2x ; parmcount: %.4x ; arglist: %.8x\n", record->Proc.rvtype, record->Proc.calltype, record->Proc.parmcount, record->Proc.arglist);
                    break;
            }

            default:
                printf("\n");
        }


        offset += sizeof(length);
        offset += length;
        ptr += length;

        fflush(stdout);
    }

    printf("EOF.\n");
    return 0;
}
