#include "common.hpp"
#include <stdio.h>

IDiaDataSource* instanciate_source(void)
{
    HRESULT hr;
    IDiaDataSource* src = NULL;

    hr = CoInitialize(NULL);
    if(FAILED(hr))
        return NULL;

    hr = CoCreateInstance(
        CLSID_DiaSource, // be sure to link with diaguids.lib
        NULL,
        CLSCTX_INPROC_SERVER, // the provider is an in-process one
        __uuidof(IDiaDataSource),
        (void **)&src
    );
    
    return src;
}

void Fatal(char *err)
{
    fprintf(stderr, "%s", err);
    exit(0);
}

IDiaSession* load_pdb_file(IDiaDataSource* src, wchar_t *pdb_path)
{
    HRESULT hr;
    IDiaSession* sess;

   hr = src->loadDataFromPdb(pdb_path);
    if(FAILED(hr))
        return NULL;
    
    hr = src->openSession(&sess);
    if(FAILED(hr))
       return NULL;

    return sess;
}

IDiaSymbol* get_symbols_root(wchar_t* pdb_path)
{
    IDiaDataSource* src = instanciate_source();
    if(src == NULL)
        Fatal("instanciate_source\n");


    IDiaSession* sess = load_pdb_file(src, pdb_path);
    if(sess == NULL)
        Fatal("load_pdb_file\n");

    IDiaSymbol* root = NULL;
    HRESULT hr = sess->get_globalScope(&root);
    if(FAILED(hr))
        Fatal("get_globalScope\n");

    return root;
}

char* tag_to_str(DWORD tag)
{
    char *s[] = {
        "SymTagNull",
        "SymTagExe",
        "SymTagCompiland",
        "SymTagCompilandDetails",
        "SymTagCompilandEnv",
        "SymTagFunction",
        "SymTagBlock",
        "SymTagData",
        "SymTagAnnotation",
        "SymTagLabel",
        "SymTagPublicSymbol",
        "SymTagUDT",
        "SymTagEnum",
        "SymTagFunctionType",
        "SymTagPointerType",
        "SymTagArrayType", 
        "SymTagBaseType", 
        "SymTagTypedef", 
        "SymTagBaseClass",
        "SymTagFriend",
        "SymTagFunctionArgType", 
        "SymTagFuncDebugStart", 
        "SymTagFuncDebugEnd",
        "SymTagUsingNamespace", 
        "SymTagVTableShape",
        "SymTagVTable",
        "SymTagCustom",
        "SymTagThunk",
        "SymTagCustomType",
        "SymTagManagedType",
        "SymTagDimension",
        "SymTagCallSite",
        "SymTagInlineSite",
        "SymTagBaseInterface",
        "SymTagVectorType",
        "SymTagMatrixType",
        "SymTagHLSLType"
    };
    
    return s[tag];
}

char* basetype_to_str(DWORD basetype)
{
    switch(basetype)
    {
        case 0:
            return "NoType";

        case 1:
            return "Void";

        case 2:
            return "Char";

        case 3:
            return "Wchar";

        case 6:
            return "Int";
        
        case 7:
            return "Uint";

        case 8:
            return "Float";

        case 9:
            return "BCD";

        case 10:
            return "Bool";

        case 13:
            return "Long";

        case 14:
            return "Ulong";

        case 25:
            return "Currency";

        case 26:
            return "Date";

        case 27:
            return "Variant";

        case 28:
            return "Complex";
        
        case 29:
            return "Bit";

        case 30:
            return "BSTR";

        case 31:
            return "Hresult";

        default:
            return "Unknow";
    }
}