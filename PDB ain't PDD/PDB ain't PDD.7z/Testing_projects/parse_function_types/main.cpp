#include <stdio.h>
#include <dia2.h>
#include <windows.h>
#include <shlwapi.h>
#include "../common.hpp"

#define PATH_TEST_FUNCTION_TYPES_W L"test_function_types.pdb"

void resolve_type(IDiaSymbol *s, unsigned int lvl)
{
    IDiaSymbol *type;
    if(s->get_type(&type) == S_OK)
    {
        for(unsigned int i = 0; i < lvl; ++i)
            printf(" ");
        
        DWORD id, tag;
        type->get_symIndexId(&id);
        type->get_symTag(&tag);

        printf("ID: %d, type: %s", id, tag_to_str(tag));
        if(tag == SymTagArrayType)
        {
            DWORD count;
            type->get_count(&count);
            printf(", count: [%d]", count);
        }

        if(tag == SymTagBaseType)
        {
            DWORD basetype;
            type->get_baseType(&basetype);
            printf(", BaseType: %s", basetype_to_str(basetype));
        }

        if(tag == SymTagUDT)
        {
            BSTR name;
            type->get_name(&name);
            printf(", name: %ws\n", name);
        }

        printf("\n");
        resolve_type(type, lvl + 4);
    }
}

int main()
{
    IDiaEnumSymbols *pEnum;
    IDiaSymbol *sym, *global;
    HRESULT hr;

    printf("tests_dia - parse_function_types\n");
    global = get_symbols_root(PATH_TEST_FUNCTION_TYPES_W);

    printf("PDB loaded, enumerating types..\n");

    hr = global->findChildren(
        SymTagFunction,
        NULL,
        nsNone,
        &pEnum
    );

    if(FAILED(hr))
        Fatal("findChildren\n");

    ULONG celt = 0;
    while(SUCCEEDED(hr = pEnum->Next(1, &sym, &celt)) && celt == 1)
    {
        BSTR name;
        if(SUCCEEDED(sym->get_name(&name)) && StrCmpW(name, L"testing_function") == 0)
        {
            DWORD id;
            sym->get_symIndexId(&id);

            printf("Found testing_function id: %d.\n", id);
            printf("Getting the ret type of the function:\n");
            resolve_type(sym, 4);
            printf("\n");

            IDiaSymbol *type;
            sym->get_type(&type);
            DWORD typetag, type_id;

            type->get_symIndexId(&type_id);
            type->get_symTag(&typetag);
            printf("Type of testing_function: tag: %s, id: %d\n", tag_to_str(typetag), type_id);
            printf("Getting the arguments of the functions:\n");
                
            IDiaEnumSymbols *pEnumChild;
            hr = type->findChildren(
                SymTagNull,
                NULL,
                nsNone,
                &pEnumChild
            );

            if(FAILED(hr))
                Fatal("findChildren\n");

            IDiaSymbol *child;
            ULONG celt2 = 0;
            while(SUCCEEDED(hr = pEnumChild->Next(1, &child, &celt2)) && celt2 == 1)
            {
                DWORD tagchild;
                child->get_symTag(&tagchild);
                        
                for(unsigned int i = 0; i < 4; ++i)
                    printf(" ");
                            
                printf("- %s\n", tag_to_str(tagchild));
                resolve_type(child, 8);
            }

            printf("We're done.\n");
            return 0;
        }
    }

    return 0;
}