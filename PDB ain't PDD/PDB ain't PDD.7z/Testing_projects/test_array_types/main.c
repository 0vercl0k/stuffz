#include <stdio.h>
#include <windows.h>

typedef struct
{
    int* a;
    char b;
    int array_1[15];
    int array_2[2][15];
    int array_3[137][2][15];
} test_array_struct_t;

int main()
{
    test_array_struct_t t = {0};
    printf("test_array_types program.\n");
    return 0;
}
