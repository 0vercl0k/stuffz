#include <windows.h>
#include <stdio.h>

#define LF_ARRAY     0x00001503
#define LF_BITFIELD  0x00001205
#define LF_CLASS     0x00001504
#define LF_STRUCTURE 0x00001505
#define LF_UNION     0x00001506
#define LF_ENUM      0x00001507
#define LF_POINTER   0x00001002
#define LF_PROCEDURE 0x00001008
#define LF_MFUNCTION 0x00001009
#define LF_ARGLIST   0x00001201
#define LF_VTSHAPE   0x0000000A
#define LF_FIELDLIST 0x00001203

#pragma pack(1)
// =================================================================
// OMF STRUCTURES
// =================================================================

typedef struct _OMF_HEADER
    {
    WORD wRecordSize; // in bytes, not including this member
    WORD wRecordType;
    }
    OMF_HEADER, *POMF_HEADER, **PPOMF_HEADER;

#define OMF_HEADER_ sizeof (OMF_HEADER)

// -----------------------------------------------------------------

typedef struct _OMF_NAME
    {
    BYTE bLength;     // in bytes, not including this member
    BYTE abName [];
    }
    OMF_NAME, *POMF_NAME, **PPOMF_NAME;


// =================================================================
// CodeView STRUCTURES
// =================================================================

#define CV_SIGNATURE_NB   'BN'
#define CV_SIGNATURE_NB09 '90BN'
#define CV_SIGNATURE_NB10 '01BN'

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

typedef union _CV_SIGNATURE
    {
    WORD  wMagic;     // 'BN'
    DWORD dVersion;   // 'xxBN'
    BYTE  abText [4]; // "NBxx"
    }
    CV_SIGNATURE, *PCV_SIGNATURE, **PPCV_SIGNATURE;

#define CV_SIGNATURE_ sizeof (CV_SIGNATURE)

// -----------------------------------------------------------------

typedef struct _CV_HEADER
    {
    CV_SIGNATURE Signature;
    LONG         lOffset;
    }
    CV_HEADER, *PCV_HEADER, **PPCV_HEADER;

#define CV_HEADER_ sizeof (CV_HEADER)

// -----------------------------------------------------------------

typedef struct _CV_DIRECTORY
    {
    WORD  wSize;      // in bytes, including this member
    WORD  wEntrySize; // in bytes
    DWORD dEntries;
    LONG  lOffset;
    DWORD dFlags;
    }
    CV_DIRECTORY, *PCV_DIRECTORY, **PPCV_DIRECTORY;

#define CV_DIRECTORY_ sizeof (CV_DIRECTORY)

// -----------------------------------------------------------------

#define sstModule     0x0120 // CV_MODULE
#define sstGlobalPub  0x012A // CV_PUBSYM
#define sstSegMap     0x012D // SV_SEGMAP

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

typedef struct _CV_ENTRY
    {
    WORD  wSubSectionType;   // sst*
    WORD  wModuleIndex;      // -1 if not applicable
    LONG  lSubSectionOffset; // relative to CV_HEADER
    DWORD dSubSectionSize;   // in bytes, not including padding
    }
    CV_ENTRY, *PCV_ENTRY, **PPCV_ENTRY;

#define CV_ENTRY_ sizeof (CV_ENTRY)

// -----------------------------------------------------------------

typedef struct _CV_NB09 // CodeView 4.10
    {
    CV_HEADER    Header;
    CV_DIRECTORY Directory;
    CV_ENTRY     Entries [];
    }
    CV_NB09, *PCV_NB09, **PPCV_NB09;

#define CV_NB09_ sizeof (CV_NB09)

// -----------------------------------------------------------------

typedef struct _CV_NB10 // PDB reference
    {
    CV_HEADER    Header;
    DWORD        dSignature;   // seconds since 01-01-1970
    DWORD        dAge;         // 1++
    BYTE         abPdbName []; // zero-terminated
    }
    CV_NB10, *PCV_NB10, **PPCV_NB10;

#define CV_NB10_ sizeof (CV_NB10)

// -----------------------------------------------------------------

typedef union _CV_DATA
    {
    CV_HEADER Header;
    CV_NB09   NB09;
    CV_NB10   NB10;
    }
    CV_DATA, *PCV_DATA, **PPCV_DATA;

#define CV_DATA_ sizeof (CV_DATA)

// -----------------------------------------------------------------

typedef struct _CV_SEGMENT
    {
    WORD  wSegment;
    WORD  wReserved;
    DWORD dOffset;
    DWORD dSize;
    }
    CV_SEGMENT, *PCV_SEGMENT, **PPCV_SEGMENT;

#define CV_SEGMENT_ sizeof (CV_SEGMENT)

// -----------------------------------------------------------------

typedef struct _CV_MODULE
    {
    WORD       wOverlay;
    WORD       wLibrary;
    WORD       wSegments;
    WORD       wStyle;      // "CV"
    CV_SEGMENT Segments []; // wSegments
 // OMF_NAME   Name;        // use CV_MODULE_NAME() to access
    }
    CV_MODULE, *PCV_MODULE, **PPCV_MODULE;

#define CV_MODULE_ sizeof (CV_MODULE)

#define CV_MODULE_NAME(_p) \
        ((POMF_NAME) ((PBYTE) (_p)->Segments + \
                      ((DWORD) (_p)->wSegments * CV_SEGMENT_)))

// -----------------------------------------------------------------

typedef struct _CV_SYMHASH
    {
    WORD  wSymbolHashIndex;
    WORD  wAddressHashIndex;
    DWORD dSymbolInfoSize;
    DWORD dSymbolHashSize;
    DWORD dAddressHashSize;
    }
    CV_SYMHASH, *PCV_SYMHASH, **PPCV_SYMHASH;

#define CV_SYMHASH_ sizeof (CV_SYMHASH)

// -----------------------------------------------------------------

#define S_PUB32  0x0203
#define S_ALIGN  0x0402

#define CV_PUB32 S_PUB32

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

typedef struct _CV_PUBSYM
    {
    OMF_HEADER Header;
    DWORD      dOffset;
    WORD       wSegment;    // 1-based section index
    WORD       wTypeIndex;  // 0
    OMF_NAME   Name;        // zero-padded to next DWORD
    }
    CV_PUBSYM, *PCV_PUBSYM, **PPCV_PUBSYM;

#define CV_PUBSYM_ sizeof (CV_PUBSYM)

#define CV_PUBSYM_DATA(_p) \
        ((PCV_PUBSYM) ((PBYTE) (_p) + CV_SYMHASH_))

#define CV_PUBSYM_SIZE(_p) \
        ((DWORD) (_p)->Header.wRecordSize + sizeof (WORD))

#define CV_PUBSYM_NEXT(_p) \
        ((PCV_PUBSYM) ((PBYTE) (_p) + CV_PUBSYM_SIZE (_p)))

// -----------------------------------------------------------------

typedef struct _CV_SEGMAPDESC
    {
    WORD  wFlags;
    WORD  wOverlay;   // 0
    WORD  wGroup;     // 0
    WORD  wFrame;     // 1-based section index
    WORD  wName;      // -1
    WORD  wClassName; // -1
    DWORD dOffset;    // 0
    DWORD dSize;      // in bytes
    }
    CV_SEGMAPDESC, *PCV_SEGMAPDESC, **PPCV_SEGMAPDESC;

#define CV_SEGMAPDESC_ sizeof (CV_SEGMAPDESC)

// -----------------------------------------------------------------

typedef struct _CV_SEGMAP
    {
    WORD          wTotal;
    WORD          wLogical;
    CV_SEGMAPDESC Descriptors [];
    }
    CV_SEGMAP, *PCV_SEGMAP, **PPCV_SEGMAP;
#pragma pack()


char *type_to_str(unsigned int type)
{
    switch(type)
    {
        case LF_ARRAY:
            return "LF_ARRAY";
        case LF_BITFIELD:
            return "LF_BITFIELD";
        case LF_CLASS:
            return "LF_CLASS";
        case LF_STRUCTURE:
            return "LF_STRUCTURE";
        case LF_UNION:
            return "LF_UNION";
        case LF_ENUM:
            return "LF_ENUM";
        case LF_POINTER:
            return "LF_POINTER";
        case LF_PROCEDURE:
            return "LF_PROCEDURE";
        case LF_MFUNCTION:
            return "LF_MFUNCTION";
        case LF_ARGLIST:
            return "LF_ARGLIST";
        case LF_VTSHAPE:
            return "LF_VTSHAPE";
        case LF_FIELDLIST:
            return "LF_FIELDLIST";

        default:
            return "UNKNOWN";
    }
}

void display_header(PCV_HEADER hdr)
{
    printf("Header\n");
    printf("Signature: %s\n", hdr->Signature.abText);
    printf("Offset SubSection Directory: %x\n", hdr->lOffset);
}


PVOID map_codeview_info(char* name)
{
    PVOID base_file = NULL;
    HANDLE hFile, hFileMap;

    hFile = CreateFile(
        name,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if(hFile == INVALID_HANDLE_VALUE)
    {
        printf("CreateFile failed.\n");
        return NULL;
    }

    hFileMap = CreateFileMapping(
        hFile,
        NULL,
        PAGE_READONLY,
        0,
        0,
        NULL
    );

    if(hFileMap == INVALID_HANDLE_VALUE)
    {
        printf("CreateFileMapping.\n");
        return NULL;
    }

    base_file = MapViewOfFile(
        hFileMap,
        FILE_MAP_READ,
        0,
        0,
        0
    );

    if(base_file == NULL)
    {
        printf("MapViewOfFile.\n");
        return NULL;
    }

    return base_file;
}

/*
    WORD  wSize;      // in bytes, including this member
    WORD  wEntrySize; // in bytes
    DWORD dEntries;
    LONG  lOffset;
    DWORD dFlags;
*/
void display_dir(PCV_DIRECTORY dir)
{
    printf("Directory:\n");
    printf("Size: %x bytes\n", dir->wSize);
    printf("EntrySize: %x bytes\n", dir->wEntrySize);
    printf("Nb Entries: %x\n", dir->dEntries);
    printf("Offset: %x\n", dir->lOffset);
    printf("Flags: %x\n", dir->dFlags);
}

int main(int argc, char* argv[])
{
    unsigned char *ptr = NULL;
    PVOID base = map_codeview_info("test.codeview.dumped");
    PCV_HEADER hdr;
    PCV_DIRECTORY dir;

    printf("File mapped at: %.8x\n", base);

    ptr = (unsigned char*)base;

    //1] Header
    hdr = (PCV_HEADER)base;
    display_header(hdr);

    ptr += hdr->lOffset;
    dir = (PCV_DIRECTORY)ptr;
    display_dir(dir);
    return 0;
}
