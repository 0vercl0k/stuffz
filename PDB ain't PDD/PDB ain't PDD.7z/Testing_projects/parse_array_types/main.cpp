#include <stdio.h>
#include <windows.h>
#include <shlwapi.h>
#include "../common.hpp"

#define PATH_TEST_ARRAY_TYPES_W L"test_array_types.pdb"

void resolve_type(IDiaSymbol *s, unsigned int lvl)
{
    IDiaSymbol *type;
    if(SUCCEEDED(s->get_type(&type)))
    {
        for(unsigned int i = 0; i < lvl; ++i)
            printf(" ");
        
        DWORD id, tag;
        type->get_symIndexId(&id);
        type->get_symTag(&tag);

        printf("ID: %d, type: %s", id, tag_to_str(tag));
        if(tag == SymTagArrayType)
        {
            DWORD count;
            type->get_count(&count);
            printf(", count: [%d]", count);
        }

        if(tag == SymTagBaseType)
        {
            DWORD basetype;
            type->get_baseType(&basetype);
            printf(", BaseType: %s", basetype_to_str(basetype));
        }

        printf("\n");
        resolve_type(type, lvl + 4);
    }
}

void print_info_type_field_struct(IDiaSymbol *s)
{
    DWORD id, tag;
    BSTR name;

    s->get_name(&name);
    s->get_symIndexId(&id);
    s->get_symTag(&tag);

    printf("- %ws - ID: %d, type: %s\n", name, id, tag_to_str(tag));
    resolve_type(s, 4);
    printf("\n");
}

int main()
{
    IDiaEnumSymbols *enu;
    IDiaSymbol *sym, *global, *child;

    global = get_symbols_root(PATH_TEST_ARRAY_TYPES_W);
    if(global == NULL)
        Fatal("get_symbols_root\n");

    HRESULT hr = global->findChildren(
        SymTagNull, // No filter, remember
        NULL,
        nsNone,
        &enu
    );

    if(FAILED(hr))
        Fatal("findChildren\n");

    ULONG celt = 0;
    while(SUCCEEDED(hr = enu->Next(1, &sym, &celt)) && celt == 1)
    {
        BSTR name;
        DWORD tag, id;
       
        if(SUCCEEDED(sym->get_name(&name)) && SUCCEEDED(sym->get_symIndexId(&id)))
        {
            if(StrCmpW(name, L"test_array_struct_t") == 0)
            {
                sym->get_symTag(&tag);
                printf("Found test_array_struct_t at id: %d, type: %s\n", id, tag_to_str(tag));
                
                IDiaEnumSymbols *enumSymbols;
                hr = sym->findChildren(
                    SymTagNull,
                    NULL,
                    nsNone,
                    &enumSymbols
                );

                if(SUCCEEDED(hr))
                {
                    ULONG celt2 = 0;
                    while(SUCCEEDED(hr = enumSymbols->Next(1, &child, &celt2)) && celt2 == 1)
                    {                        
                        BSTR childname;
                        if(child->get_name(&childname) == S_OK)
                            print_info_type_field_struct(child);
                    }

                    printf("We're done.\n", tag);
                    return 0;
                }
            }
        }
    }

    return 0;
}
