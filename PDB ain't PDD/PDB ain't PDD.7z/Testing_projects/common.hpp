#ifndef COMMON_HPP
#define COMMON_HPP

#include <windows.h>
#include <dia2.h>

void Fatal(char *err);
IDiaSymbol* get_symbols_root(wchar_t* pdb_path);
char* tag_to_str(DWORD tag);
char* basetype_to_str(DWORD basetype);

#endif