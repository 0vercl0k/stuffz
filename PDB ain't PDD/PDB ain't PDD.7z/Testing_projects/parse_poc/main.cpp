#include <stdio.h>
#include <dia2.h>
#include <windows.h>
#include <shlwapi.h>
#include "../common.hpp"

#define PATH_POC_W L"../../trigger/Debug/trigger.pdb"

void display_type(IDiaSymbol *s, unsigned int lvl)
{
    IDiaSymbol *type;
    if(s->get_type(&type) == S_OK)
    {
        for(unsigned int i = 0; i < lvl; ++i)
            printf(" ");
        
        DWORD id, tag;
        type->get_symIndexId(&id);
        type->get_symTag(&tag);

        printf("ID: %d, type: %s", id, tag_to_str(tag));
        if(tag == SymTagArrayType)
        {
            DWORD count;
            type->get_count(&count);
            printf(", count: [%d]", count);
        }

        if(tag == SymTagUDT)
        {
            BSTR name;
            type->get_name(&name);
            printf(", name: %ws", name);
        }

        if(tag == SymTagBaseType)
        {
            DWORD basetype;
            type->get_baseType(&basetype);
            printf(", BaseType: %s", basetype_to_str(basetype));
        }

        printf("\n");
        display_type(type, lvl + 4);
    }
}

void display_argtype(IDiaSymbol *s, unsigned int lvl)
{
    IDiaSymbol *parent;
    s->get_classParent(&parent);
    display_type(s, lvl + 4);
}

int main()
{
    IDiaEnumSymbols *pEnum;
    IDiaSymbol *pSymbol, *global;
    HRESULT hr;

    printf("tests_dia - parse_poc\n");
    global = get_symbols_root(PATH_POC_W);

    printf("PDB loaded, enumerating types..\n");

    hr = global->findChildren(
        SymTagFunction,
        NULL,
        nsNone,
        &pEnum
    );

    if(hr == S_OK)
    {
        ULONG celt = 0;
        while(SUCCEEDED(hr = pEnum->Next(1, &pSymbol, &celt)) && celt == 1)
        {
            BSTR name;
            if(pSymbol->get_name(&name) == S_OK && StrCmpW(name, L"ogg_sync_wrote") == 0)
            {
                DWORD id;
                pSymbol->get_symIndexId(&id);

                printf("Found %ws id: %d.\n", name, id);
                printf("Getting the ret type of the function:\n");
                display_type(pSymbol, 4);
                printf("\n");

                IDiaSymbol *type;
                pSymbol->get_type(&type);
                DWORD typetag, type_id;

                type->get_symIndexId(&type_id);
                type->get_symTag(&typetag);

                if(typetag != SymTagFunctionType)
                    getchar();

                printf("Type of testing_function: tag: %s, id: %d\n", tag_to_str(typetag), type_id);
                printf("Getting the arguments of the functions:\n");
                
                IDiaEnumSymbols *pEnumChild;
                hr = type->findChildren(
                    SymTagNull,
                    NULL,
                    nsNone,
                    &pEnumChild
                );

                if(hr == S_OK)
                {
                    IDiaSymbol *pChild;
                    ULONG celt2 = 0;
                    while(SUCCEEDED(hr = pEnumChild->Next(1, &pChild, &celt2)) && celt2 == 1)
                    {
                        DWORD tagchild;
                        pChild->get_symTag(&tagchild);
                        
                        for(unsigned int i = 0; i < 4; ++i)
                            printf(" ");
                            
                        printf("- %s\n", tag_to_str(tagchild));
                        display_argtype(pChild, 8);
                    }
                }

                printf("We're done.\n");
                return 0;
            }

            pSymbol = 0;
        }
    }

    return 0;
}