#include <stdio.h>

typedef struct
{
    unsigned char field_1[10];
    bool field_2;
} structure_t;

bool testing_function(int arg1, int* arg2, char arg3, structure_t* arg4)
{
    arg1;
    arg2;
    arg3;
    arg4;
    printf("testing_function.\n");
    return true;
}

int main()
{
    structure_t z = {0};
    printf("test_function_types program.\n");
    testing_function(1, (int*)2, 3, &z);
    return 0;
}