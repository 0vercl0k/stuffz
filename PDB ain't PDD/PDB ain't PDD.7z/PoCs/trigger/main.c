#include <stdio.h>

int BOOM[1337][1338] = {0};

void crashing_function(int a, int b, int c, int d, int e, int f, int g, int h, int i, int j, int k, int l)
{
    a;
    b;
    c;
    d;
    e;
    f;
    g;
    h;
    i;
    j;
    k;
    l;
    printf("crashing_function.\n");
}

int main()
{
    printf("yo man!\n");
    return 0;
}